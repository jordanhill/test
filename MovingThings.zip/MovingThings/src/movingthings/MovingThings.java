package movingthings;

import DLibX.DConsole;
import java.awt.Color;

public class MovingThings {

    public static void main(String[] args) {
        DConsole dc = new DConsole();
        dc.setOrigin(DConsole.ORIGIN_CENTER);
        
        int cloudX = 100;
        
        
        while(true) {

            // sky
            dc.setPaint(Color.BLUE);
            dc.fillRect(450, 300, 900, 600);

            // ground
            dc.setPaint(Color.GREEN);
            dc.fillRect(450, 550, 900, 100);

            // sun
            dc.setPaint(new Color(236, 255, 0)); // custom yellow
            dc.fillEllipse(700, 100, 80, 80);

            // cloud
            dc.setPaint(Color.WHITE);
            dc.fillEllipse(cloudX, 110, 90, 30);
            dc.fillEllipse(cloudX + 20, 120, 80, 40);
            
            // move the cloud
            cloudX += 5; // cloudX += 5  ---> cloudX = cloudX + 5;
            
            if(cloudX > 950) { // left the right side
                cloudX = -50;  // loop back to left side of screen
            }
            
            
            dc.redraw();
            dc.pause(20);  // wait for 20 milliseconds (1000 ms == 1 second)
            
            
        }
    
    }
    
}
